import sys
import pkg_resources


# This is the main module that imports and uses the CSVParser and JSONParser classes
from file_parser.abstract_subclass import CSVParser, JSONParser

if __name__ == "__main__":
    print("sys.path=", sys.path)
    # Example usage of the CSVParser class
    parser = CSVParser()
    result = parser.parse_and_process(pkg_resources.resource_filename("file_parser", "sample_data/example.csv"))
    print(result)
    # Example usage of the JSONParser class
    parser = JSONParser() 
    result = parser.parse_and_process(pkg_resources.resource_filename("file_parser", "sample_data/example.json"))
    print(result) 