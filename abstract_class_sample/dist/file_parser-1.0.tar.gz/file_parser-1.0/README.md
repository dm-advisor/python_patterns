# Python Abstract Pattern

For an implementation of the abstract pattern refer to [file_parser](https://github.com/dm-advisor/python_patterns/tree/bbf6884a6967587c408426694794756064a4faf4/abstract_class_sample/file_parser) package.
